#!/bin/bash

ifconfig net_server 192.168.8.101
