#!/bin/bash

ovs-vsctl set bridge br0 protocols=OpenFlow10,OpenFlow12,OpenFlow13


