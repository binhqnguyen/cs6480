#!/bin/bash

iptables -t nat -L
