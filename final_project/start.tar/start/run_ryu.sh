#!/bin/bash


ryu-manager --verbose --ofp-listen-host 192.168.4.100 /home/cloud/setup/ryu/ryu/app/my_simple_switch_13.py
