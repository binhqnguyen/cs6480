#!/bin/bash

ifconfig eth2 192.168.4.101
