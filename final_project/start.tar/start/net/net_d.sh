#!/bin/bash

ifconfig net_d 192.168.4.100
