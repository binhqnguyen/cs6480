#!/bin/bash

ifconfig net_cloud 192.168.10.100
