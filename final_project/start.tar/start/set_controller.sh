#!/bin/bash

ovs-vsctl set-controller br0 tcp:192.168.4.91:6633
