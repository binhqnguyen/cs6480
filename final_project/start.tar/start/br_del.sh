#!/bin/bash

ovs-vsctl del-br br0
ovs-vsctl show
